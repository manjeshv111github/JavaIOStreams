package IOStreams;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

public class BufferedReaderr {
	//Reading line by line from the external file

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		//File file = new File("‪C:\\Users\\ManjeshaV\\Desktop\\FileInputStream.txt");
		
		//since we are not direclty add the path of the file in bufferedreader class hence we are adding using filerreader class
		BufferedReader br = new BufferedReader(new FileReader("C:\\Users\\ManjeshaV\\Desktop\\FileInputStream.txt"));
		
		String s=br.readLine();
		System.out.println(s);
		
		while((s=br.readLine())!=null) {
			System.out.println(s);
		}
	}

}
