package IOStreams;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;

public class BufferedWriterr {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		BufferedWriter bw = new BufferedWriter(new FileWriter("C:\\Users\\ManjeshaV\\Desktop\\FileInputStream.txt"));
		
		bw.write("Wrting through buffere writer. \n");
		bw.write("Wrting through buffere writer1. \n");
		System.out.println("Data wtittern successfully");
		bw.close();
		
		
		

	}

}
