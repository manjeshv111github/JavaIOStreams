package IOStreams;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

public class FileInputstream {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub

		File file = new File ("C:\\Users\\ManjeshaV\\Desktop\\FileInputStream.txt");
		
		FileInputStream input = new FileInputStream(file);
		
		int i=input.read(); //which gives the ascii number for each character
		while(!(i==-1)) {  // it run till end of the file to read all the characters
			
			char ch = (char)i; // converting integer into char
			System.out.print(ch);
			i=input.read(); // reading next char
		}
		input.close();
		
		
		//Second method
		
		/*byte[] byt = new byte[100];
		
		input.read(byt);
		
		String s = new String(byt);
		
		System.out.println(s);*/
		
	}

}
