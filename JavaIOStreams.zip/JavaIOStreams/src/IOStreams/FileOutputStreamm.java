package IOStreams;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;

public class FileOutputStreamm {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		//File file = new File ("‪C:\\Users\\ManjeshaV\\Desktop\\FileInputStream.txt");
		
		FileOutputStream fo = new FileOutputStream("C:\\Users\\ManjeshaV\\Desktop\\FileInputStream.txt");
		
		String s= "Updating file1";
		
		fo.write(s.getBytes());
		System.out.println("Data wtittern successfully");
		fo.close();
		
		

	}

}
