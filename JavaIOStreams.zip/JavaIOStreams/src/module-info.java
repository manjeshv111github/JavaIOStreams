/**
 * 
 */
/**
 * 
 */
module JavaIOStreams {
}